#include "PostponeController.hpp"
#include <string>

void PostponeController::initiatePostpone() {
    int dt;
    int yt, mt;
    int valid = 0;
    int custid;
    int day;
    int month;
    int year;
    int numtrv;
    objectPostponeBean = objectPostponeUI.postponeDetails();
    custid = objectPostponeBean.getCustomerId();
    valid = objectBookingController.verifyCID(custid);
    if (valid == 1) {
        day = objectBookingController.getDay(custid);
        month = objectBookingController.getMonth(custid);
        year = objectBookingController.getYear(custid);
        numtrv = objectBookingController.getNumtrv(custid);
        objectPostponeBean = objectPostpone.updatePostponeDetails(objectPostponeBean, day, month, year, numtrv);
        dt = objectPostponeUI.postponeday(objectPostponeBean);
        mt = objectPostponeUI.postponemonth();
        yt = objectPostponeUI.postponeyear();
        int updatevalid = objectBookingController.updateDate(dt, mt, yt, custid);
        if (updatevalid) {
            objectPostponeUI.updateStatus();
        }
    } else {
        objectPostponeUI.displayStatus();
    }
}
