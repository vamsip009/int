#ifndef _DEFCUSTOMERCONTROLLER
#define _DEFCUSTOMERCONTROLLER

#include "CustomerUI.hpp"
#include "CustomerBean.hpp"
#include "Customer.hpp"

#include<iostream>
#include<string>

class CustomerController {
    CustomerUI objectCustomerUI;
    CustomerBean objectCustomerBean;
    Customer objectCustomer;
public:
    void initiateCustomer();
    int verifyBookingid(int);
};
#endif
