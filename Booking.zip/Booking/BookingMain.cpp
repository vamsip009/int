#include "BookingController.hpp"

#include <iostream>

#include <string>

#include <vector>

int main()

{

    BookingController bookingControllerObject;

    bookingControllerObject.initiateBooking();

    return 0;
}