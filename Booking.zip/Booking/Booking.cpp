#include "Booking.hpp"

BookingBean Booking::calculateBill(BookingBean objectBookingBean)

{
    double value;

    int dest = objectBookingBean.getDest();

    switch (dest)

    {

    case 1:
        bill = bill + 170;
        break;

    case 2:
        bill = bill + 150;
        break;

    case 3:
        bill = bill + 220;
        break;

    case 4:
        bill = bill + 139;
        break;

    case 5:
        bill = bill + 192;
        break;

    case 6:
        bill = bill + 340;
        break;

    case 7:
        bill = bill + 370;
        break;

    case 8:
        bill = bill + 410;
       case 9:
        bill = bill + 220;
        break;

    case 10:
        bill = bill + 250;
        break;

    case 11:
        bill = bill + 280;
        break;

    case 12:
        bill = bill + 310;
        break;

    case 13:
        bill = bill + 320;
        break;

    default:
        bill = 0;
        break;
    }

    int couple = objectBookingBean.getCouple();

    if (couple == 1) {
        bill = (0.6 * bill);
    }

    int notravelers = objectBookingBean.getNotravelers();

    if (notravelers > 0)

    {
        value = 0.4 * bill * notravelers;
        bill = bill + value;
    }
        int child = objectBookingBean.getChild();
    if (child == 1) {
        bill = bill + (0.2 * bill);
    }
    int sp = objectBookingBean.getSp();

    switch (sp) {
    case 1:
        bill = bill - (0.08 * bill);
        break;
    case 2:
        bill = bill - (0.12 * bill);
        break;
    }
        int location = objectBookingBean.getLocation();
        switch (location)
        {
        case 1:
        bill = bill + (0.1*bill);
        break;
        case 2:
        bill = bill + (0.12*bill);
        break;
        case 3:
        bill = bill + (0.14*bill);
        break;
        case 4:
        bill = bill + (0.16*bill);
        break;
        case 5:
        bill = bill + (0.18*bill);
        break;
        }
    objectBookingBean.setBill(bill);
    return objectBookingBean;

}
