#ifndef _DEFBOOKINGMODEL

#define _DEFBOOKINGMODEL

#include "BookingBean.hpp"

#include <iostream>

#include <vector>

#include <string>

#include <ctime>

#include <cstdio>

using namespace std;

class Booking

    {
    double bill;

public:
    vector<BookingBean> vectorBookingDetails;
    BookingBean calculateBill(BookingBean);
};

#endif
