#include "BookingBean.hpp"
int BookingBean::getCusomertId()
{
    return this->customerId;
}
double BookingBean::getBill()
{
    return this->bill;
}
int BookingBean::getTransactionId()
{
    return this->transactionId;
}
int BookingBean::getAccountNumber()
{
    return this->accountNumber;
}
string BookingBean::getTransactionMode()
{
    return this->transactionMode;
}
string BookingBean::getBankName()
{
    return this->bankName;
}
int BookingBean::getDay()
{
    return this->day;
}
int BookingBean::getMonth()
{
    return this->month;
}
int BookingBean::getYear()
{
    return this->year;
}
int BookingBean::getDest()
{
    return this->dest;
}
int BookingBean::getNotravelers()
{
return this->notravelers;
}
int BookingBean::getCouple()
{
    return this->couple;
}
int BookingBean::getChild()
{
    return this->child;
}
int BookingBean::getSp()
{
    return this->sp;
}
void BookingBean::setDest(int dest)
{
    this->dest = dest;
}
int BookingBean::getLocation()
{
    return this->location;
}
void BookingBean::setNotravelers(int notravelers)
{
    this->notravelers = notravelers;
}
void BookingBean::setCouple(int couple)
{
    this->couple = couple;
}
void BookingBean::setChild(int child)
{
    this->child = child;
}
void BookingBean::setSp(int sp)
{
    this->sp = sp;
}
void BookingBean::setDay(int day)
{
    this->day = day;
void BookingBean::setMonth(int month)
{
    this->month = month;
}
void BookingBean::setYear(int year)
{
    this->year = year;
}
void BookingBean::setCusomertId(int customerId)
{
    this->customerId = customerId;
}
void BookingBean::setBill(double bill)
{
    this->bill = bill;
}
void BookingBean::setTransactionId(int transactionId)
{
    this->transactionId = transactionId;
}
void BookingBean::setAccountNumber(int accountNumber)
{
    this->accountNumber = accountNumber;
}
void BookingBean::setTransactionMode(string transactionMode)
{
    this->transactionMode = transactionMode;
}
void BookingBean::setBankName(string bankName)
{
    this->bankName = bankName;
}
void BookingBean::setLocation(int location)
{
    this->location = location;
}
   