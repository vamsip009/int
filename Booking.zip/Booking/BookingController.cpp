#include "BookingController.hpp"

void BookingController::initiateBooking()

{
    int customerid;
    int valid = 1;
        objectBookingBean = objectBookingUI.bookingDetails();
        if (valid) {
        objectBookingBean = objectBooking.calculateBill(objectBookingBean);

        objectBookingUI.displayBill(objectBookingBean);
    }
    else {
        objectBookingUI.bookingStatus();
    }
}

