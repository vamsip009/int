#include "PostponeController.hpp"
#include <string>
void PostponeController::initiatePostpone()
{   int dt;
    int yt,mt;
    int valid = 1;
    int custid;
    int day = 20;
    int month = 11;
    int year = 2016;
    int amount = 1000;
    objectPostponeBean = objectPostponeUI.postponeDetails();

    if (valid == 1) {

        objectPostponeBean = objectPostpone.updatePostponeDetails(objectPostponeBean, day, month, year);
                dt=objectPostponeUI.postponeday(objectPostponeBean);
                mt=objectPostponeUI.postponemonth();
                yt=objectPostponeUI.postponeyear();

    }
    else {
                objectPostponeUI.displayStatus();
    }
}
