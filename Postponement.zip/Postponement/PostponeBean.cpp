#include "PostponeBean.hpp"

void PostponeBean::setCustomerId(int customerId)
{
    this->customerId = customerId;
}
int PostponeBean::getCustomerId()
{
    return this->customerId;
}

void PostponeBean::setDay(int day)
{
    this->day = day;
}
int PostponeBean::getDay()
{
    return this->day;
}

void PostponeBean::setMonth(int month)
{
    this->month = month;
}
int PostponeBean::getMonth()
{
    return this->month;
}
void PostponeBean::setYear(int year)
{
    this->year = year;
}
int PostponeBean::getYear()
{
    return this->year;
}
void PostponeBean::setAmountPaid(int amountPaid)
{
    this->amountPaid = amountPaid;
}
int PostponeBean::getAmountPaid()
{
    return this->amountPaid;
}