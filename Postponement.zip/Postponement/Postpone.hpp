#ifndef _DEFPOSTPONEMODEL
#define _DEFPOSTPONEMODEL
#include "PostponeBean.hpp"
#include "PostponeUI.hpp"
#include <iostream>
#include <vector>
#include <string>
#include <ctime>

using namespace std;
 struct Date {
        int d, m, y;
    };

class Postpone {
public:


    int diff;
    int amountPaid;
    int cday, cmonth, cyear;
    int cdate;
    int difference;
    PostponeBean objectPostponeBean;

    PostponeBean updatePostponeDetails(PostponeBean, int, int, int);
};
#endif
