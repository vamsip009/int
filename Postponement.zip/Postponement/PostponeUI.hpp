#ifndef _DEFPOSTPONEVIEW
#define _DEFPOSTPONEVIEW
#include "PostponeBean.hpp"

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class PostponeUI {

public:
    int customerId;
    int day;
    int month;
    int year;
    int d,m,y;
    PostponeBean objectPostponeB;

    PostponeBean postponeDetails();
        int postponeday(PostponeBean);
                int postponemonth();
        int postponeyear();
        void displayStatus();
};
#endif
