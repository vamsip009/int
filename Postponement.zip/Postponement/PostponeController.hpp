#ifndef _DEFPOSTPONECONTROLLER
#define _DEFPOSTPONECONTROLLER
#include "PostponeUI.hpp"
#include "PostponeBean.hpp"
#include "Postpone.hpp"

#include <iostream>
#include <string>
#include <vector>
#include <cctype>
class PostponeController {
        public:
        struct Date {
                   int d, m, y;
                   };
    PostponeUI objectPostponeUI;
    PostponeBean objectPostponeBean;
    Postpone objectPostpone;



    void initiatePostpone();
};
#endif
