#ifndef _DEFPOSTPONEBEAN
#define _DEFPOSTPONEBEAN

#include <iostream>
#include <string.h>

using namespace std;
class PostponeBean {
public:
    int customerId;
    int amountPaid;
    int day;
    int month;
    int year;
    void setDay(int);
    int getDay();
    void setMonth(int);
    int getMonth();
    void setYear(int);
    int getYear();
    void setCustomerId(int);
    int getCustomerId();
    void setAmountPaid(int);
    int getAmountPaid();
};
#endif

