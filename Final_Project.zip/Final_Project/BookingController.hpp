#ifndef _DEFBOOKINGCONTROLLER
#define _DEFBOOKINGCONTROLLER

#include "BookingUI.hpp"
#include "Booking.hpp"
#include "BookingBean.hpp"
#include "CustomerController.hpp"
#include "HotelController.hpp"

#include<iostream>
#include<vector>

using namespace std;

class BookingController
{
        BookingUI objectBookingUI;
        BookingBean objectBookingBean;
        Booking objectBooking;
        CustomerController objectCustomerController;
        HotelController objectHotelController;

        public:

        int initiateBooking();
        BookingBean validateDetails(int,int);
};
#endif
