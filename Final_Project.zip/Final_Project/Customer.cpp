#include"Customer.hpp"

CustomerBean Customer::checkDetails(string number)
{
CustomerBean cbean;
   int i;
   for (i=0;i<customerDetailsVector.size();i++)
       {

 if(customerDetailsVector[i].getCustomerPhone().compare(number)==0 )
          {
           cbean= customerDetailsVector[i];
            break;
          }

       }

return cbean;


}

int Customer::addCustomerDetails(string name,string phone,string email,int age,string address)
   {
    static int id=1000;
    id++;
    objectCustomerBean.setCustomerId(id);
    objectCustomerBean.setCustomerName(name);
    objectCustomerBean.setCustomerPhone(phone);
    objectCustomerBean.setCustomerEmail(email);
    objectCustomerBean.setCustomerAge(age);
    objectCustomerBean.setCustomerAddress(address);

     customerDetailsVector.push_back(objectCustomerBean);

    return id;
   }
CustomerBean Customer::viewCustomer(int){



}
int Customer::retrieveDetails(int cid){

int i;
for(i=0;i<customerDetailsVector.size();i++)
       {

 if(customerDetailsVector[i].getCustomerId()==cid )
          {
           return 1;
          }

       }

return 0;
}

