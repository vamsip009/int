#ifndef _DEFCANCELLATIONVIEW
#define _DEFCANCELLATIONVIEW

#include "CancellationBean.hpp"

#include<iostream>
#include<string>
#include<vector>

using namespace std;

class CancellationUI
{



       CancellationBean objectCancellationBean;

       int cancellationId;

       int transactionId;

       int customerId;

       string cancellationDate;

        public:

        CancellationBean cancellationDetails();

        void displayCancellationRefundDetails(CancellationBean);

         void displayCustomerStatus(string );
};

#endif
