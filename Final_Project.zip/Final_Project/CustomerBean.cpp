#include "CustomerBean.hpp"

void CustomerBean::setCustomerId(int customerId){
this->CustomerId=customerId;
}

int CustomerBean::getCustomerId(){
return this->CustomerId;
}

void CustomerBean::setCustomerName(string CustomerName){
this->CustomerName=CustomerName;
}

string CustomerBean::getCustomerName(){
return this->CustomerName;
}

void CustomerBean::setCustomerAddress(string CustomerAddress){
this->CustomerAddress=CustomerAddress;
}

string CustomerBean::getCustomerAddress(){
return this->CustomerAddress;
}

void CustomerBean::setCustomerPhone(string CustomerPhone){
   this->CustomerPhone=CustomerPhone;
}

string CustomerBean::getCustomerPhone(){
    return this->CustomerPhone;
}

string CustomerBean::getCustomerEmail(){
 return this->CustomerEmail;
}

void CustomerBean::setCustomerEmail(string CustomerEmail){
this->CustomerEmail=CustomerEmail;
}

void CustomerBean::setCustomerAge(int age){
 this->CustomerAge=age;

}
int CustomerBean::getCustomerAge(){
    return this->CustomerAge;
}

