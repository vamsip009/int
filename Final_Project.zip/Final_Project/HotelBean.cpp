#include "HotelBean.hpp"

int HotelBean::getHotelId()
{
return this->hotelId;
}

string HotelBean::getHotelName(){
return this->hotelName;

 }
string HotelBean::getHotelAddress(){
return this->hotelAddress;
}
string HotelBean::getRoomType(){
return this->roomType;
}
int HotelBean::getRoomCost(){
return this->roomCost;
}
string HotelBean::getCheckInDate(){
return this->checkInDate;
}
int HotelBean::getConvention(){
return this->convention;
}
int HotelBean::getRoomAvailability(){
return this->roomAvailability;
}
int HotelBean::getDiscount(){
return this->discount;
}
int HotelBean::getTypeOfCustomer(){
return this->typeOfCustomer;

}

  void HotelBean::setHotelId(int HotelId){
        this->hotelId=HotelId;
   }
  void HotelBean::setHotelName(string HotelName){
        this->hotelName=HotelName;
      }
  void HotelBean::setHotelAddress(string HotelAddress){
        this->hotelAddress=HotelAddress;
     }
  void HotelBean::setRoomType(string roomType){
     this->roomType=roomType;
     }
  void HotelBean::setRoomCost(int roomCost){
     this->roomCost=roomCost;
     }
  void HotelBean::setCheckInDate(string CheckDate){
      this->checkInDate=CheckDate;
     }
  void HotelBean::setConvention(int conventnion){
       this->convention=convention;
      }
  void HotelBean::setRoomAvailability(int roomAvailability){
       this->roomAvailability=roomAvailability;
    }
  void HotelBean::setDiscount(int discount){
   this->discount=discount;
      }
  void HotelBean::setTypeOfCustomer(int typeOfCustomer){
    this->typeOfCustomer=typeOfCustomer;
      }


