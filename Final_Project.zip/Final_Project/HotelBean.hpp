#ifndef _DEFHOTELBEAN
#define _DEFHOTELBEAN

#include<iostream>
#include<string>

using namespace std;

class HotelBean
{

  int hotelId;
  string hotelName;
  string hotelAddress;
  string roomType;
  int roomCost;
  string checkInDate;
  int convention;
  int roomAvailability;
  int discount;
  int typeOfCustomer;

  public:

  int getHotelId();
  string getHotelName();
  string getHotelAddress();
  string getRoomType();
  int getRoomCost();
  string getCheckInDate();
  int getConvention();
  int getRoomAvailability();
  int getDiscount();
  int getTypeOfCustomer();


  void setHotelId(int);
  void setHotelName(string);
  void setHotelAddress(string);
  void setRoomType(string);
  void setRoomCost(int);
  void setCheckInDate(string);
  void setConvention(int);
  void setRoomAvailability(int);
  void setDiscount(int);
  void setTypeOfCustomer(int);

};
#endif

