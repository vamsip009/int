#ifndef _DEFCUSTOMERVIEW
#define _DEFCUSTOMERVIEW

#include "CustomerBean.hpp"

#include<iostream>
#include<string>
#include<vector>

using namespace std;



class CustomerUI
{

            CustomerBean objectCustomerBean;
            string name,email,address;
            string phone;
            int age;

                public:
              int customerMenu();
              CustomerBean checkDetails();
              CustomerBean customerRegistration();
              void displayDetails(CustomerBean);
              void displayStatus(int);
              char getChoice();
};
 #endif

