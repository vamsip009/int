#ifndef _DEFCUSTOMERMODEL
#define _DEFCUSTOMERMODEL

#include "CustomerBean.hpp"
#include "CustomerUI.hpp"

#include<iostream>
#include<vector>
#include<string>
using namespace std;

class Customer
{


                 CustomerBean objectCustomerBean;
                 vector <CustomerBean> customerDetailsVector;
                public:
                     CustomerBean checkDetails(string);
                     int addCustomerDetails(string ,string ,string ,int ,string );
                     CustomerBean viewCustomer(int);
                     int retrieveDetails(int );

  };
 #endif
