#include "BookingController.hpp"

int BookingController::initiateBooking()
{
    int guestCount,customerId;
        int roomCost,verifyId,discoutTotal;
        string roomtype,checkinDate;
        int extracharge=0;
        int conventionCenter,discount,totalAmount;

        vector<BookingBean>guestDetails;

        guestDetails=objectBookingUI.enterGuestDetails(guestCount);

        guestCount=guestDetails[0].getGuestsCount();

        //cout<<"guestcount:"<<guestCount;

        objectBookingBean=objectBookingUI.enterBookingDetails();

        roomtype=objectBookingBean.getRoomType();

           if(roomtype=="Single")
                roomCost=80;
           else if(roomtype=="Double")
                roomCost=120;
           else if(roomtype=="Executive")
                roomCost=160;
          else if(roomtype=="Suite")
                roomCost=180;
          else if(roomtype=="Independent")
                roomCost=250;
         else
                roomCost=-1;

//      roomCost=objectHotelController.fetchRoomDetails(roomtype);


        if(roomCost==-1)
        {
                objectBookingUI.displayStatus("invalid room type");
                return 0;
        }

        checkinDate=objectBookingBean.getCheckInDate();

        customerId=objectBookingBean.getCustomerId();

        //verifyId=objectCustomerController.validateDetails(customerId);
      //        if(verifyId!=1)
    //  {
    //          objectBookingUI.displayStatus("invalid customer id");
    //                  return 0;
     //         }
          objectBooking.storeGuestDetails(guestDetails);

          discount=objectHotelController.viewDiscount();
          cout<<discount;
          conventionCenter=objectBookingBean.getConvention();

        extracharge=objectBooking.calculateExtraCharge(roomCost,guestCount,customerId);

        //cout<<"extra charge:"<<extracharge;


        objectBookingBean=objectBooking.calculateBill(roomCost,extracharge,discount,conventionCenter,checkinDate,customerId,guestCount);

        discoutTotal=objectBookingBean.getDiscount();

        totalAmount=objectBookingBean.getAmountPaid();

        extracharge=objectBookingBean.getTaxAmount();

        int transactionId=objectBookingBean.getTransactionId();

        int currencytype=objectBookingUI.viewBillDetails(customerId,discoutTotal,extracharge,totalAmount,transactionId);

        if(currencytype==0)
        {
                objectBookingUI.displayStatus("your transaction has been cancelled ivalid currency type");
        }
        else{
                  int amount=objectBooking.makepayment(currencytype,totalAmount);
                          objectBookingUI.paymentAmount(amount,totalAmount,currencytype);
        }
}
BookingBean BookingController::validateDetails(int transactionId,int validation)
{
        objectBookingBean=objectBooking.viewDetails(transactionId,validation);
                 return  objectBookingBean;

}
