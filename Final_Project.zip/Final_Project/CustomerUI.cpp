#include"CustomerUI.hpp"

int CustomerUI::customerMenu()
{
  int ch1;
  bool valid=false;
  while(!valid)
       {
        cout<<"\n*****************Customer Management****************\n\n";
        cout<<"**********************Menu*******************\n\n";
        cout<<"\t\t1.Existing User\t\t2.NewUser\n\n";
        cout<<"Enter your choice:\n\n";
        cin>>ch1;
        switch(ch1)
          {
         case 1:
             valid=true;
             break;
         case 2:
             valid=true;
             break;
         default:
        cout<<"\033[31mWrong choice!!! Please enter from 1-2\033[0m"<<endl;
        cin.clear();
        cin.ignore(80,'\n');
         }
     }
return ch1;
}

CustomerBean CustomerUI::checkDetails()
{

   cout<<"Enter CustomerPhone:";
   cin>>phone;
   objectCustomerBean.setCustomerPhone(phone);

   return objectCustomerBean;

}

CustomerBean CustomerUI::customerRegistration()
{
  cout<<"Enter Customer Name:";

  cin>>name;
  cout<<"Enter Customer Phone Number:";
  cin>>phone;
  cout<<"Enter Customer Email:";
  cin>>email;
  cout<<"Enter Customer Age:";
  cin>>age;
  cout<<"Enter Customer Address:";
  cin>>address;

  objectCustomerBean.setCustomerName(name);
  objectCustomerBean.setCustomerPhone(phone);
  objectCustomerBean.setCustomerEmail(email);
  objectCustomerBean.setCustomerAge(age);
  objectCustomerBean.setCustomerAddress(address);

 return objectCustomerBean;

}
void CustomerUI::displayDetails(CustomerBean objectCustomerBean)
{

      cout<<"\n";
        cout<<objectCustomerBean.getCustomerId()<<"\t";
        cout<<objectCustomerBean.getCustomerName()<<"\t";
        cout<<objectCustomerBean.getCustomerPhone()<<"\t\t";
        cout<<objectCustomerBean.getCustomerAge()<<"\t";
        cout<<objectCustomerBean.getCustomerAddress()<<"\t";

}
void CustomerUI::displayStatus(int id)
{

   cout<<"yourcustomer id: "<<id;
}

 char CustomerUI::getChoice()
{
        char ch;
        cout<<endl;
        cout<<"\n\nDo you want to continue?"<<endl;
        cout<<"\nPress y|y for yes"<<endl;
        cin>>ch;
        return ch;
}




