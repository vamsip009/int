#include "HotelController.hpp"

void HotelController::initiateHotelDetails()
{

        vector<HotelBean>hotelDetails;
        vector<HotelBean>roomDetails;
        int check;
        string date,roomtype;
        int hid,available;
        int typeOfDiscount,discountAmount;

         objectHotel.insertHotelDetails(1,"Illam","shollinganallur" );
         objectHotel.insertHotelDetails(2,"GateWay","karapakkam" );
         objectHotel.insertHotelDetails(3,"Novotel","siruseri" );

        hotelDetails=objectHotel.viewHotelDetails();


         hid=objectHotelUI.displayHotelDetails(hotelDetails);

         objectHotel.insertRoomDetails("Single",80 );
         objectHotel.insertRoomDetails("Double",120);
         objectHotel.insertRoomDetails("Executive",160);
         objectHotel.insertRoomDetails("Suite",180);
         objectHotel.insertRoomDetails("Independent",250);
         objectHotel.insertRoomDetails("Convention",5000);

        roomDetails=objectHotel.viewRoomDetails();

        roomtype=objectHotelUI.displayRoomDetails(roomDetails);


        date=objectHotelUI.checkAvailability();

        available=objectHotel.checkAvailability(hid,roomtype,date);

        if(available==1)
        {

        objectHotelUI.displayAvailability("available");
        }
        else
        {
        objectHotelUI.displayAvailability("not available");
        }



        check=objectHotelUI.checkDiscount();
        if(check==1)
        {
        typeOfDiscount=objectHotelUI.selectDiscountType();
        if(typeOfDiscount!=0)
        {
                discountAmount=objectHotel.discountApplicable(typeOfDiscount);
                objectHotelUI.displayDiscountDetails(discountAmount);
        }
        }
}

int HotelController::fetchRoomDetails(string roomtype)
{

        int cost;
      cout<<"Entered into details";
       cout<<roomtype;
         objectHotel.viewRoomDetails();
      cost=objectHotel.fetchRoomCost(roomtype);
           cout<< cost;
        return cost;

}
int HotelController::viewDiscount(){

        int typeOfDiscount,discountAmount;

        typeOfDiscount=objectHotelUI.selectDiscountType();

        if(typeOfDiscount!=0)
        {
                discountAmount=objectHotel.discountApplicable(typeOfDiscount);
        }
return discountAmount;
}
