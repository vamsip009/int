#include "Hotel.hpp"

void Hotel::insertHotelDetails(int hotelid,string hotelname,string hoteladdress)
{
        objectHotelBean.setHotelId(hotelid);
        objectHotelBean.setHotelName(hotelname);
        objectHotelBean.setHotelAddress(hoteladdress);
        vectorHotelDetails.push_back(objectHotelBean);
}

void Hotel::insertRoomDetails(string roomtype,int roomcost)
{
                objectHotelBean.setRoomType(roomtype);
                objectHotelBean.setRoomCost(roomcost);
            vectorRoomDetails.push_back(objectHotelBean);
}

vector<HotelBean> Hotel::viewHotelDetails()
{
        vector<HotelBean> displayHotelvector;
        int i;
          for (i=0;i<vectorHotelDetails.size();i++)
          {
        displayHotelvector.push_back(vectorHotelDetails[i]);
            }
        return displayHotelvector;
}

vector<HotelBean> Hotel::viewRoomDetails()
{

        vector<HotelBean> displayRoomvector;
        int i;
          for (i=0;i<vectorRoomDetails.size();i++)
       {
        displayRoomvector.push_back(vectorRoomDetails[i]);
            }
        return displayRoomvector;
}

 int Hotel::checkAvailability(int hid,string roomtype,string checkindate)
 {
        int i,j,valid1,valid2;
      for (i=0;i<vectorHotelDetails.size();i++)
       {
                 if(vectorHotelDetails[i].getHotelId()==hid )
          {
           valid1=1;
              }

           }
    for(j=0;j<vectorRoomDetails.size();j++)
    {
         if(vectorRoomDetails[j].getRoomType().compare(roomtype)==0)
            {
                 valid2=1;
            }

     }
        if(valid1==1 && valid2==1)
        {
                return 1;
        }

        return 0;
}
int Hotel::fetchRoomCost(string roomtype)
{
        int j;
   for(j=0;j<vectorRoomDetails.size();j++)
     {
         if(vectorRoomDetails[j].getRoomType().compare(roomtype)==0)
         {
                 return vectorRoomDetails[j].getRoomCost();

         }
         return -1;
    }
}
int Hotel::discountApplicable(int type)
{
int discount;

        switch(type)
        {
            case 1:discount=4;break;
            case 2:discount=7;break;
            case 3:discount=14;break;
            default:return 0;
        }
return discount;

}

