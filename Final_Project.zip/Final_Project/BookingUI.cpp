#include "BookingUI.hpp"

vector<BookingBean> BookingUI::enterGuestDetails(int& count)
{
        vector<BookingBean>guestDetails;
        int age;
        string name,nationality,number;
        cout<<"\t*******************Booking Process*******************\n";
        cout<<"Enter number of Guests:";
        cin>>count;
        objectBookingBean.setGuestsCount(count);
       for(int i=1;i<=count;i++)
        {
         cout<<"Enter Guest "<<i<<" Name:";
         cin>>name;
         objectBookingBean.setguestName(name);
         cout<<"Enter Guest "<<i<<"Nationality:";
         cin>>nationality;
         objectBookingBean.setguestNationality(nationality);

         cout<<"Enter Guest "<<i<<"Number:";
         cin>>number;
         objectBookingBean.setguestNumber(number);

         cout<<"Enter Guest"<<i<<"Age:";
         cin>>age;
         objectBookingBean.setguestAge(age);
        guestDetails.push_back(objectBookingBean);
        }
return guestDetails;

}

BookingBean BookingUI::enterBookingDetails()
{
int customerid,value;
string roomtype;
string checkInDate;
char c;
cout<<"enter customer id:";
cin>>customerid;
objectBookingBean.setCustomerId(customerid);
cout<<"enter room type:\n";
cout<<"1.Single\n2.Double\n3.Executive\n4.Suite\n5.Independent:";
 cin>>roomtype;
objectBookingBean.setRoomType(roomtype);
cout<<"enter check-in-date(dd-mm-yyyy):";
cin>>checkInDate;
 objectBookingBean.setCheckInDate(checkInDate);

cout<<"Do you need of convention center y/n:";
cin>>c;
        if(c=='y' || c=='Y')
        {
         cout<<"Enter day of the convention center needed 1-weekday ,2- weekend: ";
        cin>>value;
          if(value==1)
            objectBookingBean.setConvention(5000);
          else
            objectBookingBean.setConvention(10000);
        }
        else
        objectBookingBean.setConvention(0);
return objectBookingBean;
}
void BookingUI::displayStatus(string msg)
{
        cout<<"\033[31m"<<msg<<"\033[0m"<<endl;

}
int BookingUI::viewBillDetails(int customerId,int discoutTotal,int extracharge,int totalAmount,int transactionId )
{
        char ch;
        int currencytype;
        cout<<"\t*********************Bill Details*********************\n\n";
        cout<<"Customer Id:"<<customerId<<endl;
        cout<<"Transaction Id:"<<transactionId<<endl;
        cout<<"Base Amount:"<<totalAmount-discoutTotal-extracharge<<endl;
        cout<<"Discounts:"<<discoutTotal<<endl;
        cout<<"Tax Amount:"<<extracharge<<endl;
        cout<<"Net Amount:"<<totalAmount<<endl;
        cout<<"continue to make payment y/n:";
        cin>>ch;
        if(ch=='y' || ch=='Y')
       {
                cout<<"Enter currecy type:"<<endl;
                cout<<"1-pound,2-Yen,3-Dollar"<<endl;
                cin>>currencytype;
                return currencytype;
        }
        else
                return 0;
}
void BookingUI::paymentAmount(int total,int currency,int currencytype)
{
        cout<<"Amount to be paid in Euros:"<<currency<<endl;
        switch(currencytype)
        {
        case 1:cout<<"Amount to be paid in pounds:"<<total<<endl;
        break;
        case 2:cout<<"Amount to be paid in Yen:"<<total<<endl;
        break;
        case 3:cout<<"Amount to be paid in Dollars:"<<total<<endl;
        break;
        }
}
