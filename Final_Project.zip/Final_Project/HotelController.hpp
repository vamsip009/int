#ifndef _DEFHOTELCONTROLLER
#define _DEFHOTELCONTROLLER

#include "HotelUI.hpp"
#include "HotelBean.hpp"
#include "Hotel.hpp"

#include<iostream>
#include<string>

using namespace std;

class HotelController
{
        HotelUI objectHotelUI;
        HotelBean objectHotelBean;
        Hotel objectHotel;
        public:
        void initiateHotelDetails();
        int fetchRoomDetails(string);
        int viewDiscount();


};
#endif

