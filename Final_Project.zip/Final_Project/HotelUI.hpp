#ifndef _DEFHOTELVIEW
#define _DEFHOTELVIEW

#include "HotelBean.hpp"

#include<iostream>
#include<string>
#include<vector>

using namespace std;

class HotelUI
{
        HotelBean objectHotelBean;

        public:

        int displayHotelDetails(vector<HotelBean>);
        string  displayRoomDetails(vector<HotelBean>);
        string checkAvailability();
        void displayAvailability(string);
        int checkDiscount();
        int selectDiscountType();
        void displayDiscountDetails(int);
};
#endif
