#include"CancellationBean.hpp"


int CancellationBean::getCancellationId()
{
return this->cancellationId;
}

int CancellationBean::getTransactionId()
{
        return this->transactionId;
}

string CancellationBean::getCancellationDate()
{
return this->cancellationDate;
}

string CancellationBean::getBookingDate()
{
        return this->bookingDate;
}

int CancellationBean::getRefund()
{
 return this->refund;
}

int CancellationBean::getAmountPaid()
{
 return this->amountPaid;
}
int CancellationBean::getCustomerId()
{
return this->customerId;
}
void CancellationBean::setCustomerId(int id)
{
 this->customerId=id;

}
void CancellationBean::setCancellationId(int cancellationId)
{

this->cancellationId=cancellationId;

}

void CancellationBean::setTransactionId(int transactionId)
{

this->transactionId=transactionId;

}

void CancellationBean::setCancellationDate(string cancellationDate)
{

this->cancellationDate=cancellationDate;

}

void CancellationBean::setBookingDate(string bookingDate)
{

        this->bookingDate=bookingDate;


}

void CancellationBean::setRefund(int refund)
{

this->refund=refund;

}

void CancellationBean::setAmountPaid(int amountPaid)
{

this->amountPaid=amountPaid;

}