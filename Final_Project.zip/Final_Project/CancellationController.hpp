#ifndef _DEFCANCELLATIONCONTROLLER

#define _DEFCANCELLATIONCONTROLLER

#include "CancellationUI.hpp"

#include "Cancellation.hpp"

#include "CancellationBean.hpp"

#include "BookingController.hpp"

#include "CustomerController.hpp"

#include<iostream>

#include<algorithm>

#include<string>

#include<vector>

using namespace std;


class CancellationController

{
        BookingController objectBookingController;

        CustomerController objectCustomerController;

        CancellationUI objectCancellationUI;

        CancellationBean objectCancellationBean;

        Cancellation objectCancellation;


        public:

   int initiateCancellation();

};

#endif
