#include "CustomerController.hpp"

void CustomerController::initiateCustomer()
{
    char choice;
    string name;
    string address;
    string phone;
    string email;
    int id;
    int age;



   do{
       int ch=objectCustomerUI.customerMenu();
       switch(ch)
           {
            case 1:


                    objectCustomerBean=objectCustomerUI.checkDetails();
                    phone=objectCustomerBean.getCustomerPhone();
                    objectCustomerBean=objectCustomer.checkDetails(phone);
                    objectCustomerUI.displayDetails(objectCustomerBean);


                break;

            case 2:


                objectCustomerBean=objectCustomerUI.customerRegistration();

               name=objectCustomerBean.getCustomerName();
               phone=objectCustomerBean.getCustomerPhone();
               email=objectCustomerBean.getCustomerEmail();
               age=objectCustomerBean.getCustomerAge();
               address=objectCustomerBean.getCustomerAddress();

                id=objectCustomer.addCustomerDetails(name,phone,email,age,address);
                objectCustomerUI.displayStatus(id);

               break;

        default:
                cout<<"Wrong choice!!! Please enter from 1-2:"<<endl;


            }

     choice=objectCustomerUI.getChoice();
       } while(choice=='y' || choice=='Y');
}
int CustomerController::validateDetails(int cid)
{
   int value;
        value=objectCustomer.retrieveDetails(cid);
        return value;

}


