#ifndef _DEFCANCELLATIONMODEL

#define _DEFCANCELLATIONMODEL

#include "CancellationBean.hpp"

#include<iostream>

#include<vector>

#include<string>

#include <ctime>

#include <cstdio>

using namespace std;


class Cancellation

{
    CancellationBean ObjectCancellationBean;

        vector<CancellationBean>cancellationDetails;
        public:
        CancellationBean calculateRefund(string,string,int,int,int);


};

#endif
