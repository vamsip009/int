#ifndef _DEFBOOKINGVIEW
#define _DEFBOOKINGVIEW

#include "BookingBean.hpp"

#include<iostream>
#include<string>
#include<vector>

using namespace std;

class BookingUI
{
        BookingBean objectBookingBean;

        public:
        vector<BookingBean> enterGuestDetails(int&);
        BookingBean enterBookingDetails();
        void displayStatus(string);

        int viewBillDetails(int,int,int,int,int);
        void paymentAmount(int,int,int);
};
#endif