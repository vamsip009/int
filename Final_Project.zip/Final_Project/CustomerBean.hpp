#ifndef _DEFCUSTOMERBEAN
#define _DEFCUSTOMERBEAN

#include<iostream>
#include<string>

using namespace std;
class CustomerBean{

         int CustomerId;
         string CustomerName;
         string CustomerAddress;
         string CustomerPhone;
         string CustomerEmail;
        int CustomerAge;
        public:

         void setCustomerId(int);
         int getCustomerId();
         void setCustomerName(string);
         string getCustomerName();
         void setCustomerAddress(string);
         string getCustomerAddress();
         string getCustomerPhone();
         void setCustomerPhone(string );
         int getCustomerAge();
         void setCustomerAge(int);
         string getCustomerEmail();
         void setCustomerEmail(string);
};
#endif

