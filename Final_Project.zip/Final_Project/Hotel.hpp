#ifndef _DEFHOTELMODEL
#define _DEFHOTELMODEL

#include"HotelBean.hpp"

#include<iostream>
#include<map>
#include<vector>
#include<string>

using namespace std;

class Hotel{

        HotelBean objectHotelBean;

        vector<HotelBean>vectorHotelDetails;

    vector<HotelBean>vectorRoomDetails;

        public:

        void insertHotelDetails(int,string,string);
        void insertRoomDetails(string,int);

        vector<HotelBean> viewHotelDetails();

         vector<HotelBean> viewRoomDetails();

    int checkAvailability(int ,string,string);

        int discountApplicable(int);

        int fetchRoomCost(string);


};
#endif
