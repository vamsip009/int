#ifndef _DEFCUSTOMERCONTROLLER
#define _DEFCUSTOMERCONTROLLER

#include "CustomerUI.hpp"
#include "CustomerBean.hpp"
#include "Customer.hpp"

#include<iostream>
#include<string>
#include<vector>

using namespace std;

class CustomerController
{

        CustomerUI objectCustomerUI;
        CustomerBean objectCustomerBean;
        Customer objectCustomer;
        public:
        void initiateCustomer();
        int validateDetails(int);

};
#endif

