#include"HotelUI.hpp"

int HotelUI::displayHotelDetails(vector<HotelBean> vectorHotelBean)
{
        int i,hid;
        cout<<"\n";
        cout<<"*****************The Hotels Available are:*****************\n\n";
        cout<<"HotelId\t\tHotelName\tHotelAddress\n";
        cout<<"-------------------------------------------------\n";
         for(i=0;i<vectorHotelBean.size();i++)
              {
                cout<<vectorHotelBean[i].getHotelId()<<"\t\t";
                cout<<vectorHotelBean[i].getHotelName()<<"\t\t";
                cout<<vectorHotelBean[i].getHotelAddress()<<"\t\t";
                cout<<"\n";
              }
        cout<<"select a hotel by Id:";
        cin>>hid;
return hid;

}
string HotelUI::displayRoomDetails(vector<HotelBean> vectorHotelBean)
{
        string roomtype;
        int i;
        cout<<"\n\n\n";
        cout<<"*****************The Rooms Available are:*****************\n\n";
        cout<<"RoomType\tRoomCost(Euros)\n";
        cout<<"------------------------\n";
        for(i=vectorHotelBean.size()-1;i>=0;i--)
          {
           cout<<vectorHotelBean[i].getRoomType()<<"\t";
           cout<<vectorHotelBean[i].getRoomCost()<<"\t";
           cout<<"\n";
          }
      cout<<"\tconvention center is available and price may vary based on day\n";
      cout<<"select a room by roomtype:";
        cin>>roomtype;
return roomtype;
}

string HotelUI::checkAvailability()
{

   string date;
   cout<<"Enter checkIn Date(dd-mm-yyyy) :"<<"\t";
   cin>>date;
return date;

}
void HotelUI::displayAvailability(string msg)
{
        cout<<"\n";
        cout<<"The rooms are"<<msg;
        cout<<"\n";
}

int HotelUI::checkDiscount()
{
        char check;

        cout<<"Do you want to check discount details y/n:";
        cin>>check;
        if(check=='y' || check=='Y')
                return 1;
        else
                return 0;
}
int HotelUI::selectDiscountType()
{
        int type,age;

        cout<<"\nEnter type of the customer:";
        cout<<"\n1.Frequent Customer 2.HoneymoonCouple 3.senior citizens\n";
        cin>>type;
        if(type==3)
           {
                cout<<"enter age";
                cin>>age;
                if(age<=65)
                  {
                        cout<<"discount not applicable"<<endl;
                        return 0;
                  }
        }
return type;
}
void HotelUI::displayDiscountDetails(int discount)
{
        cout<<"\n The Discount  is:"<<discount<<"%."<<endl;

}


