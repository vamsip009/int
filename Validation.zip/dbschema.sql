create table customer(
	customerId number(10) constraint customer_pk PRIMARY KEY,
	customerName varchar2(30),
	customerPhone varchar2(10),
	customerEmail varchar2(30),
	customerAge number(3),
	customerAddress varchar2(20)
);

create table Hotel(
HotelId number(10) constraint Hotel_pk PRIMARY KEY,
HotelName varchar2(20),
HotelAddress varchar2(20)
);

create table Room(
RoomType varchar2(20) constraint Room_pk PRIMARY KEY,
RoomCost number(20)
);

create table availability(
HotelId number(10) references Hotel(HotelId),
RoomType varchar2(20)references Room(RoomType),
CheckInDate varchar2(10) NOT NULL,
availability number(10),
primary key (HotelId,RoomType,CheckInDate)
 );

create table GuestDetails(
GuestName varchar2(30),
GuestNationality varchar2(20),
GuestAge number(10),
CustomerId number(10) references customer(customerId),
CheckInDate varchar2(10) NOT NULL,
primary key(CheckInDate,CustomerId)
);
create table Booking(
  TRANSACTIONID NUMBER(20) primary key,
 BOOKINGDATE  VARCHAR2(10) NOT NULL,
 ROOMTYPE  VARCHAR2(20),
 CUSTOMERID  NUMBER(10),
 TAXAMOUNT   NUMBER(5),
 DISCOUNT  NUMBER(5),
 AMOUNTPAID  NUMBER(10)
);
create table cancellation(

 CANCELLATIONID NUMBER(10) primary key,
 CUSTOMERID NUMBER(10) references customer(customerId),
 TRANSACTIONIONID NUMBER(10)  references Booking(TRANSACTIONID),
 CANCELLATIONDATE  VARCHAR2(20),
 BOOKINGDATE VARCHAR2(10),
 AMOUNTPAID NUMBER(10)

);