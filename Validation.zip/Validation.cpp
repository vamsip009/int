#include "Validation.hpp"

string Validation::stringValidation(string guestName)
{
   int valid=1;
        do{
        valid=0;
        if(guestName.length()<3)
        {
                cout<<"Guest name length must be atleast 3 characters long"<<endl;
                cin>>guestName;
                valid=1;
         }
        if (guestName.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ") != std::string::npos)
        {
                std::cerr << "Invalid name\n";
                cout<<"Please enter valid name:"<<endl;
                cin>>guestName;
                valid=1;
        }


        }while(valid);
        return guestName;
}


string Validation::mobileNumberValidation(string phonenumber)
{


int n;
int Result;
int valid=1;
        do{
        valid=0;
        n=phonenumber.size();

        istringstream convert(phonenumber);
        if ( !(convert >> Result) )
        {
         Result = 0;

        if (isdigit(Result) && n==10)
        {
          if( Result>0&& Result<10000000000)
                valid=1;
                 cout<<"valid mobile number"<<endl;
        }

        else
        {
        cout<<"invalid format "<<endl;
        cout<<"please enter the correct phonenumber";
        cin>>phonenumber;

        }
   } while(valid);
    return phonenumber;
}
int Validation::integerValidation(int value)
{
        int valid=0;

         do
        {       if(value<=0)
                {
                cout<<" Invalid value.Please enter the correctvalue \t";
                cin>>value;
                valid=1;
                }
        }while(valid );

        return value;
}


string Validation::dateValidation(string date)
{       int dd, mm,yy;
        int valid =1;

        do{

                sscanf(date.c_str(), "%d-%d-%d", &dd,&mm,&yy);
                valid=0;
                
        if(yy<1580 || yy>9999)
                {
                valid=1;
                cout<<"Invalid Year\n";

                }
        switch (mm)
        {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12 :

                        if(dd<1 || dd>31){
                        cout<<"\nInvalid date\n";
                        valid=1;
                        }
                        else
                        {
                        //cout<<"The entered date is:\t"<<dd<<"-"<<mm<<"-"<<yy;
                        valid=0;
                        }
                break;
                case 4:
                case 6:
                case 9:
                case 11 :

                        if(dd<1||dd>30){
                        cout<<"Invalid date\n";
                        valid=1;
                        }
                        else
                        valid=0;
                        //cout<<"The entered date is:\t"<<dd<<"-"<<mm<<"-"<<yy;
                        break;
                case 2 :
                if (yy%4==0)
                {
             if(dd<1||dd>29){
                        cout<<"Invalid date\n";
                        valid=1;
                        }
                        else
                        valid=0;
                        //cout<<"The entered date is:\t"<<dd<<"-"<<mm<<"-"<<yy;
                }
                if(yy%4!=0)
                {
                        if(dd<1||dd>28){
                        valid=1;
                        cout<<"Invalid date\n";
                        }
                        else
                //      cout<<"The entered date is:\t"<<dd<<"-"<<mm<<"-"<<yy;
                        valid=0;
                }
                break;
                default:
                        cout<<"Invalid Month\n";
                        valid=1;
        }
        if(valid!=0)
        cout<<"Renter Date:";
        cin>>date;

        }while(valid);


}

string Validation::emailValidation(string email)
{
        string test;
        int valid=1;
        bool isCharacter();
        bool isNumber();
        bool isValidEmailAddress(string);
           do{
        test=email;
        valid=0;
        if(isValidEmailAddress(test) )
                cout << "Your email address is valid.";
        else{

                cout << "Your email address is invalid, Please re-enter.";
                valid=1;
                getline(cin, email);
         }
        }while(valid);

        return email;;
}

bool isCharacter(const char Character)
{
        return ( (Character >= 'a' && Character <= 'z') || (Character >= 'A' && Character <= 'Z'));
}

bool isNumber(const char Character)
{
        return ( Character >= '0' && Character <= '9');
}

bool isValidEmailAddress(string email)
{

        if(!isCharacter(email[0]))
                return 0;
        int AtOffset = -1;
        int DotOffset = -1;
        int Length=email.length();

        for(unsigned int i = 0; i < Length; i++)
        {
                if(email[i] == '@')
                        AtOffset = (int)i;
                else if(email[i] == '.')
                        DotOffset = (int)i;
        }
        
        if(AtOffset == -1 || DotOffset == -1)
                return 0;
        if(AtOffset > DotOffset)
                return 0;
        return !(DotOffset >= ((int)Length-1));

}
                                                                                                                      
										  