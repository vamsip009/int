#ifndef _DEFVALIDATION
#define _DEFVALIDATION

#include<iostream>
#include<cstring>
#include<cctype>
#include<iomanip>
#include<locale>
#include<sstream>
#include<string>
#include<stdio.h>
using namespace std;

class Validation
{
        public:
        string stringValidation(string);

        int integerValidation(int);

        int transactionIdValidation(int);

        string dateValidation(string);

        string emailValidation(string);

        string mobileNumberValidation(string);
};
#endif
