#include "CancellationBean.hpp"

void CancellationBean::setCustomerId(int customerId) {
    this->customerId = customerId;
}

int CancellationBean::getCustomerId() {
    return this->customerId;
}

void CancellationBean::setDay(int day) {
    this->day = day;
}

int CancellationBean::getDay() {
    return this->day;
}

void CancellationBean::setMonth(int month) {
    this->month = month;
}

int CancellationBean::getMonth() {
    return this->month;
}

void CancellationBean::setYear(int year) {
    this->year = year;
}

int CancellationBean::getYear() {
    return this->year;
}

void CancellationBean::setAmountPaid(int amountPaid) {
    this->amountPaid = amountPaid;
}

int CancellationBean::getAmountPaid() {
    return this->amountPaid;
}