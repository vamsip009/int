#include "PostponeController.hpp"
#include <string>

void PostponeController::initiatePostpone() {
    int dt;
    int yt, mt;
    int valid = 1;
    int custid;
    int day=29;
    int month=10;
    int year=2016;
    int numtrv=2;
    objectPostponeBean = objectPostponeUI.postponeDetails();
    
    if (valid == 1) {
       
        objectPostponeBean = objectPostpone.updatePostponeDetails(objectPostponeBean, day, month, year, numtrv);
        dt = objectPostponeUI.postponeday(objectPostponeBean);
        mt = objectPostponeUI.postponemonth();
        yt = objectPostponeUI.postponeyear();
        int updatevalid = 1;
        if (updatevalid) {
            objectPostponeUI.updateStatus();
        }
    } else {
        objectPostponeUI.displayStatus();
    }
}
