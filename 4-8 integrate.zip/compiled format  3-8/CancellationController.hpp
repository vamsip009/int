#ifndef _DEFCANCELLATIONCONTROLLER
#define _DEFCANCELLATIONCONTROLLER
#include "CancellationUI.hpp"
#include "CancellationBean.hpp"
#include "Cancellation.hpp"


#include <iostream>
#include <string>
#include <vector>
#include <cctype>

class CancellationController {
public:
    struct Date {
        int d, m, y;
    };

    CancellationUI objectCancellationUI;
    CancellationBean objectCancellationBean;
    Cancellation objectCancellation;
    void initiateCancellation();
};
#endif
