#include"CustomerUI.hpp"

int CustomerUI::CustomerDetails() {
    int a1;
    bool credible = false;
    while (!credible) {
        cout << "$$$$$$$$$$$$$$$$$$$$$$Details$$$$$$$$$$$$$$$$$$$$$$$$" << endl;
        cout << "\t\t\t\t\t1.Current Customer\n\n\t\t\t\t\t2.Required Customer" << endl;
        cout << "Enter your option" << endl;
        cin>>a1;
        switch (a1) {
            case 1:
                credible = true;
                break;
            case 2:
                credible = true;
                break;
            default:
                cout << "\[ You Have Entered a Wrong choice!!! Please enter from 1-2" << endl;
        }
    }
    return a1;
}

CustomerBean CustomerUI::reviewDetails() {
    cout << "Enter your Emailid:";
    cin>>customeremail;
    objectCustomerBean.setCustomerEmail(customeremail);
    return objectCustomerBean;
}

CustomerBean CustomerUI::CustomerEnrollment() {
    cout << "Enter Customer Name:";
    cin>>customername;
    cout << "Enter Customer Phone Number:";
    cin>>customerphone;
    cout << "Enter Customer Email:";
    cin>>customeremail;
    cout << "Enter Customer Type:";
    cin>>customertype;
    cout << "Enter Customer Age:";
    cin>>customerage;
    cout << "Enter Customer Address:";
    cin>>customeraddress;
    objectCustomerBean.setCustomerName(customername);
    objectCustomerBean.setCustomerPhone(customerphone);
    objectCustomerBean.setCustomerEmail(customeremail);
    objectCustomerBean.setCustomerType(customertype);
    objectCustomerBean.setCustomerAge(customerage);
    objectCustomerBean.setCustomerAddress(customeraddress);

    return objectCustomerBean;

}

void CustomerUI::viewDetails(CustomerBean objectCustomerBean) {
    cout << endl;
    cout << objectCustomerBean.getCustomerName() << endl;
    cout << objectCustomerBean.getCustomerPhone() << endl;
    cout << objectCustomerBean.getCustomerEmail() << endl;
    cout << objectCustomerBean.getCustomerType() << endl;
    cout << objectCustomerBean.getCustomerAge() << endl;
    cout << objectCustomerBean.getCustomerAddress() << endl;
}

void CustomerUI::viewpage(int customerid) {
    cout << "customerid is:" << customerid;
}

char CustomerUI::getSelect() {
    char a;
    cout << endl;
    cout << "\nWould you like to continue?" << endl;
    cout << "\nPress y|y for yes" << endl;
    cin>>a;
    return a;
}
