#ifndef _DEFCUSTOMERVIEW
#define _DEFCUSTOMERVIEW
#include "CustomerBean.hpp"

#include<iostream>
#include<vector>
#include<string>

using namespace std;

class CustomerUI {
    CustomerBean objectCustomerBean;
    string customertype;
    string customername;
    int customerage;
    string customeraddress;
    string customerphone;
    string customeremail;
public:
    int CustomerDetails();
    CustomerBean reviewDetails();
    CustomerBean CustomerEnrollment();
    void viewDetails(CustomerBean);
    void viewpage(int);
    char getSelect();
};
#endif
