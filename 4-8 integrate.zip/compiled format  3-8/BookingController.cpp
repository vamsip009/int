#include "BookingController.hpp"

void BookingController::initiateBooking() {
    int customerid;
    int valid = 1;
    objectBookingBean = objectBookingUI.bookingDetails();
    if (valid) {
        objectBookingBean = objectBooking.calculateBill(objectBookingBean);
        objectBookingUI.displayBill(objectBookingBean);
    } else {
        objectBookingUI.bookingStatus();
    }
}

int BookingController::verifyCID(int cid) {
    int valid = 0;
    valid = objectBooking.verifyCid(cid);
    return valid;
}

int BookingController::getDay(int cid) {
    int day = 0;
    day = objectBooking.getDay(cid);
    return day;
}

int BookingController::getMonth(int cid) {
    int month = 0;
    month = objectBooking.getMonth(cid);
    return month;
}

int BookingController::getYear(int cid) {
    int year = 0;
    year = objectBooking.getYear(cid);
    return year;
}

int BookingController::getNumtrv(int cid) {
    int numtrv = 0;
    numtrv = objectBooking.getNumtrv(cid);
    return numtrv;
}

int BookingController::updateDate(int d, int m, int y, int cid) {
    int dp = d;
    int mp = m;
    int yp = y;
    int valid = 0;
    valid = objectBooking.updateDate(dp, mp, yp, cid);
    return valid;
}

