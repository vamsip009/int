#include "CancellationController.hpp"


void CancellationController::initiateCancellation() {
    int dt;
    int yt, mt;
    int valid = 1;
    int custid;
    int day = 29;
    int month = 10;
    int year =2016;
    int numtrv = 2;
    objectCancellationBean = objectCancellationUI.cancellationDetails();
    if (valid == 1) {
        objectCancellationBean = objectCancellation.updateCancellationDetails(objectCancellationBean, day, month, year, numtrv);
    } else {
        objectCancellationUI.displayStatus();
    }
}
