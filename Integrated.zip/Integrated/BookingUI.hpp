#ifndef _DEFBOOKINGUI
#define _DEFBOOKINGUI

#include "BookingBean.hpp"

#include <iostream>
#include <string>
#include <vector>

using namespace std;

class BookingUI {

    BookingBean objectBookingBean;
        int day;
    int month;
    int year;
    int customerId;
    int accountNumber;
    string transactionMode;
    int dest;
    int notravelers;
    int couple;
    int child;
    int sp;
    string bankName;
    int location;

public:
    BookingBean bookingDetails();
    void bookingStatus();
    void displayBill(BookingBean);
};

#endif
