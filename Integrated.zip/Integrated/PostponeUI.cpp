#include "PostponeUI.hpp"
PostponeBean PostponeUI::postponeDetails()
{
    cout << "Enter Customer Id:";
    cin >> customerId;
    cout << "Enter day";
    cin >> day;
    cout << "Enter month";
    cin >> month;
    cout << "Enter year";
    cin >> year;
    objectPostponeB.setCustomerId(customerId);
    objectPostponeB.setDay(day);
    objectPostponeB.setMonth(month);
    objectPostponeB.setYear(year);
    return objectPostponeB;
}
int  PostponeUI::postponeday(PostponeBean objectPostponeB)
{
        cout<<"The amount to be paid"<<objectPostponeB.getAmountPaid();
        cout<<"enter your postponement date"<<endl;
        cin>>d;
        return d;
}
int  PostponeUI::postponemonth()
{
        cout<<"enter your postponement month"<<endl;
        cin>>m;

        return m;
}
int  PostponeUI::postponeyear()
{
        cout<<"enter your postponement year"<<endl;
        cin>>y;

        return y;
}

void PostponeUI::displayStatus()
{

        cout<<"Your Customer id is invalid"<<endl;
}
void PostponeUI::displayStatus()
{

        cout<<"Your Postpone date is successfully changed"<<endl;
}
