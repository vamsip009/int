#include"Customer.hpp"

CustomerBean Customer::reviewDetails(string email){

CustomerBean cdetail;
   int b=0;
   while(b<=CustomerDetailsVector.size())
       {
    
 if(CustomerDetailsVector[b].getCustomerEmail().compare(email)==0 )
          {
           cdetail= CustomerDetailsVector[b];
           break;
          }
        b++;
       }

return cdetail;
}

int Customer::addCustomerDetails(string customertype,int customerage,string customername,string customeraddress,string customeremail,string customerphone)
{
  static int customerid=100000;
    objectCustomerBean.setCustomerId(customerid);
    objectCustomerBean.setCustomerType(customertype);
    objectCustomerBean.setCustomerName(customername);
    objectCustomerBean.setCustomerAge(customerage);
    objectCustomerBean.setCustomerAddress(customeraddress);
    objectCustomerBean.setCustomerPhone(customerphone);
    objectCustomerBean.setCustomerEmail(customeremail);
    
    
     CustomerDetailsVector.push_back(objectCustomerBean);
    customerid++;
    return customerid;
}

int Customer:: verifyBID(int custid)
{
	int valid=0;
	int b=0;
   while(b<=CustomerDetailsVector.size())
       {
    
 if(CustomerDetailsVector[b].getCustomerId().compare(custid)==0 )
          {
           valid=1;
           break;
          }
        b++;
       }

return valid;
	
}
