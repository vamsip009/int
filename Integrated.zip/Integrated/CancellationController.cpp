#include "CancellationController.hpp"
#include <string>
void CancellationController::initiateCancellation()
{   int dt;
    int yt,mt;
    int valid=0;
    int custid;
    int day ;
    int month ;
    int year ;
    int numtrv;
    objectCancellationBean = objectCancellationUI.cancellationDetails();
    custid=objectCancellationBean.getCustomerId();
	valid=objectBookingController.verifyCID(custid);
    if (valid == 1) {
    day=objectBookingController.getDay(custid);
	month=objectBookingController.getMonth(custid);
	year=objectBookingController.getYear(custid);
	numtrv=objectBookingController.getNumtrv(custid);
    objectCancellationBean = objectCancellation.updateCancellationDetails(objectCancellationBean, day, month, year,numtrv);
    }
    else {
                objectCancellationUI.displayStatus();
    }
}
