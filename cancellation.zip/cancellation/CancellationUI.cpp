#include "CancellationUI.hpp"
CancellationBean CancellationUI::cancellationDetails()
{
    cout << "Enter Customer Id:";
    cin >> customerId;
    cout << "Enter day";
    cin >> day;
    cout << "Enter month";
    cin >> month;
    cout << "Enter year";
    cin >> year;
    objectCancellationB.setCustomerId(customerId);
    objectCancellationB.setDay(day);
    objectCancellationB.setMonth(month);
    objectCancellationB.setYear(year);
    return objectCancellationB;
}
int  CancellationUI::cancellationday(CancellationBean objectCancellationB)
{
        cout<<"The amount to be paid"<<objectCancellationB.getAmountPaid();
        cout<<"enter your cancellationment date"<<endl;
        cin>>d;
        return d;
}
int  CancellationUI::cancellationmonth()
{
        cout<<"enter your cancellationment month"<<endl;
        cin>>m;

        return m;
}
int  CancellationUI::cancellationyear()
{
        cout<<"enter your cancellationment year"<<endl;
        cin>>y;

        return y;
}

void CancellationUI::displayStatus()
{

        cout<<"Your Customer id is invalid"<<endl;
}
