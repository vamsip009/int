#ifndef _DEFCANCELLATIONVIEW
#define _DEFCANCELLATIONVIEW
#include "CancellationBean.hpp"

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class CancellationUI {

public:
    int customerId;
    int day;
    int month;
    int year;
    int d,m,y;
    CancellationBean objectCancellationB;

    CancellationBean postponeDetails();
        int postponeday(CancellationBean);
                int postponemonth();
        int postponeyear();
        void displayStatus();
};
#endif
