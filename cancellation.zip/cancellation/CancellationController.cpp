#include "CancellationController.hpp"
#include <string>
void CancellationController::initiateCancellation()
{   int dt;
    int yt,mt;
    int valid = 1;
    int custid;
    int day = 20;
    int month = 11;
    int year = 2016;
    int amount = 1000;
    objectCancellationBean = objectCancellationUI.cancellationDetails();

    if (valid == 1) {

        objectCancellationBean = objectCancellation.updateCancellationDetails(objectCancellationBean, day, month, year);
                dt=objectCancellationUI.cancellationday(objectCancellationBean);
                mt=objectCancellationUI.cancellationmonth();
                yt=objectCancellationUI.cancellationyear();

    }
    else {
                objectCancellationUI.displayStatus();
    }
}
