#include "CancellationController.hpp"
#include <iostream>
#include <string>
#include <vector>
int main()
{
    CancellationController cancellationControllerObject;
    cancellationControllerObject.initiateCancellation();
    return 0;
}

