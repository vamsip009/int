#ifndef _DEFCUSTOMERBEAN
#define _DEFCUSTOMERBEAN

#include<iostream>
#include<string>
using namespace std;

class CustomerBean {
    int customerid;
    int customerage;
    string customertype;
    string customername;
    string customeraddress;
    string customerphone;
    string customeremail;
public:
    void setCustomerId(int);
    int getCustomerId();
    void setCustomerType(string);
    string getCustomerType();
    void setCustomerName(string);
    string getCustomerName();
    void setCustomerAge(int);
    int getCustomerAge();
    void setCustomerAddress(string);
    string getCustomerAddress();
    void setCustomerPhone(string);
    string getCustomerPhone();
    void setCustomerEmail(string);
    string getCustomerEmail();
};
#endif
