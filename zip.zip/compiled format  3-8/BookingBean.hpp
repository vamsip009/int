#ifndef _DEFBOOKINGBEAN
#define _DEFBOOKINGBEAN

#include <iostream>

#include <string>

using namespace std;

class BookingBean {
    int notvlrs;
    int dest;
    int notravelers;
    int couple;
    int child;
    int sp;
    int transactionId;
    double bill;
    int day;
    int month;
    int year;
    int customerId;
    int accountNumber;
    string transactionMode;
    string bankName;
    int location;
public:
    int getDest();
    int getNotravelers();
    int getCouple();
    int getChild();
    int getSp();
    int getDay();
    int getMonth();
    int getYear();
    int getCusomertId();
    int getTransactionId();
    int getAccountNumber();
    double getBill();
    int getLocation();
    string getTransactionMode();
    string getBankName();
    int getNotvlrs();

    void setNotvlrs(int notvlrs);
    void setDest(int dest);
    void setNotravelers(int notravelers);
    void setCouple(int couple);
    void setChild(int child);
    void setSp(int sp);
    void setDay(int day);
    void setMonth(int Month);
    void setYear(int Year);
    void setBill(double bill);
    void setCusomertId(int customerId);
    void setTransactionId(int transactionId);
    void setAccountNumber(int accountNumber);
    void setTransactionMode(string transactionMode);
    void setBankName(string bankName);
    void setLocation(int location);
};
#endif
