#include"CustomerBean.hpp"
#include<string>

void CustomerBean::setCustomerId(int customerid)
{
this->customerid=customerid;
} 
int CustomerBean::getCustomerId()
{
return this->customerid;
}

void CustomerBean::setCustomerType(string customertype)
{
this->customertype=customertype;
}

string CustomerBean::getCustomerType()
{
 return this->customertype;
}


void CustomerBean::setCustomerName(string customername)
{
this->customername=customername;
} 
string CustomerBean::getCustomerName()
{
return this->customername;
}

void CustomerBean::setCustomerAge(int customerage)
{
   this->customerage=customerage;
}
int CustomerBean::getCustomerAge()
{
    return this->customerage;
}

void CustomerBean::setCustomerAddress(string customeraddress)
{
this->customeraddress=customeraddress;
}
string CustomerBean::getCustomerAddress()
{
return this->customeraddress;
}

void CustomerBean::setCustomerPhone(string customerphone)
{
   this->customerphone=customerphone;
}
string CustomerBean::getCustomerPhone()
{
    return this->customerphone;
}

void CustomerBean::setCustomerEmail(string customeremail)
{
this->customeremail=customeremail;
} 

string CustomerBean::getCustomerEmail()
{
 return this->customeremail;
}



