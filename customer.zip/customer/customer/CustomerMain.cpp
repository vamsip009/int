#include "CustomerController.hpp"
#include<iostream>

int main()
{
        CustomerController customerControllerobject;
        
        CustomerControllerobject.initiateCustomer();
        
	return 0;
}

