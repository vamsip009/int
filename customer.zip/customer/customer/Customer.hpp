#ifndef _DEFCUSTOMER
#define _DEFCUSTOMER
#include "CustomerBean.hpp"
#include "CustomerUI.hpp"
#include<iostream>
#include<string>
#include<vector>

using namespace std;
class Customer
{
    public:

    CustomerBean objectCustomerBean;
    vector <CustomerBean> CustomerDetailsVector;
  
  
   
     CustomerBean reviewDetails(string);
     int addCustomerDetails(string,int,string,string,string,string);

};
#endif
