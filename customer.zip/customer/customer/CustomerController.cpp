#include "CustomerController.hpp"
#include <string>

void CustomerController:: initiateCustomer()
{
   int customerid;
   int customerage;
   char select;
   string customername;
   string customeraddress;
   string customeremail;
   string customertype;
   string customerphone;
   do{
      int a=objectCustomerUI.CustomerDetails();
       switch(a)
           {
            case 1:
		     //Current Customer
	
		    objectCustomerBean=objectCustomerUI.reviewDetails();
            customeremail=objectCustomerBean.getCustomerEmail();
		    objectCustomerBean=objectCustomer.reviewDetails(customeremail);
		    objectCustomerUI.viewDetails(objectCustomerBean);
			                 
		break;

	        case 2:
		    //Required Customer

		    objectCustomerBean=objectCustomerUI.CustomerEnrollment();

            customertype=objectCustomerBean.getCustomerType();
            customerage=objectCustomerBean.getCustomerAge();
            customername=objectCustomerBean.getCustomerName();
            customeraddress=objectCustomerBean.getCustomerAddress();
            customeremail=objectCustomerBean.getCustomerEmail();
            customerphone=objectCustomerBean.getCustomerPhone();
                                             
	     customerid=objectCustomer.addCustomerDetails(customertype,customerage,customername,customeraddress,customeremail,customerphone);
	     objectCustomerUI.viewpage(customerid);

         break;

	    default:
		cout<<" Wrong choice. Please access from 1-2 :"<<endl;
	    }
    select=objectCustomerUI.getSelect();
       }while(select=='y' || select=='Y');
}






