#include "Booking.hpp"

BookingBean Booking::calculateBill(BookingBean objectBookingBean)

{    notvlrs=2;
    double value;
    int dest = objectBookingBean.getDest();
    switch (dest)

    {
    case 1:
        bill = bill + 170;
        break;

    case 2:
        bill = bill + 150;
        break;
    case 3:
        bill = bill + 220;
        break;
    case 4:
        bill = bill + 139;
        break;
    case 5:
        bill = bill + 192;
        break;
    case 6:
        bill = bill + 340;
        break;
    case 7:
        bill = bill + 370;
        break;
    case 8:
        bill = bill + 410;
       case 9:
        bill = bill + 220;
        break;
    case 10:
        bill = bill + 250;
        break;
    case 11:
        bill = bill + 280;
        break;
    case 12:
        bill = bill + 310;
        break;
    case 13:
        bill = bill + 320;
        break;
    default:
        bill = 0;
        break;
    }
    int couple = objectBookingBean.getCouple();
    if (couple == 1) {
		notvlrs=notvlrs-1;
        bill = (0.6 * bill);
    }
    int notravelers = objectBookingBean.getNotravelers();

    if (notravelers > 0)
    {   
        notvlrs=notvlrs+notravelers;
        value = 0.4 * bill * notravelers;
        bill = bill + value;
    }
        int child = objectBookingBean.getChild();
    if (child == 1) {
        bill = bill + (0.2 * bill);
    }
    int sp = objectBookingBean.getSp();

    switch (sp) {
    case 1:
        bill = bill - (0.08 * bill);
        break;
    case 2:
        bill = bill - (0.12 * bill);
        break;
    }
        int location = objectBookingBean.getLocation();
        switch (location)
        {
        case 1:
        bill = bill + (0.1*bill);
        break;
        case 2:
        bill = bill + (0.12*bill);
        break;
        case 3:
        bill = bill + (0.14*bill);
        break;
        case 4:
        bill = bill + (0.16*bill);
        break;
        case 5:
        bill = bill + (0.18*bill);
        break;
        }
    objectBookingBean.setNotvlrs(notvlrs);
    objectBookingBean.setBill(bill);
	vectorBookingDetails.push_back(objectBookingBean);
    return objectBookingBean;
}

int Booking:: verifyCid(int custid)
{
	int valid=0;
	int b=0;
   while(b<=vectorBookingDetails.size())
       {
 if(vectorBookingDetails[b].getCusomertId() == custid)
          {
           valid=1;
           break;
          }
        b++;
       }
return valid;	
}
int Booking:: getDay(int custid)
{
	int day;
	int b=0;
   while(b<=vectorBookingDetails.size())
       {
 if(vectorBookingDetails[b].getCusomertId() == custid )
          {
           day=vectorBookingDetails[b].getDay();
           break;
          }
        b++;
       }
return day;	
}
int Booking:: getMonth(int custid)
{
	int month;
	int b=0;
   while(b<=vectorBookingDetails.size())
       {
 if(vectorBookingDetails[b].getCusomertId() == custid)
          {
           month=vectorBookingDetails[b].getMonth();
           break;
          }
        b++;
       }
return month;	
}
int Booking:: getYear(int custid)
{
	int year;
	int b=0;
   while(b<=vectorBookingDetails.size())
       {
 if(vectorBookingDetails[b].getCusomertId() == custid )
          {
           year=vectorBookingDetails[b].getYear();
           break;
          }
        b++;
       }
return year;	
}
int Booking:: getNumtrv(int custid)
{
	int notrvlrs;
	int b=0;
   while(b<=vectorBookingDetails.size())
       {
 if(vectorBookingDetails[b].getCusomertId() == custid )
          {
           notrvlrs=vectorBookingDetails[b].getNotvlrs();
           break; 
          }
        b++;
       }
return notrvlrs;	
}
int Booking:: updateDate(int d,int m,int y,int custid)
{
	int valid=0;
	int b=0;
   while(b<=vectorBookingDetails.size())
       {
 if(vectorBookingDetails[b].getCusomertId() == custid )
          {
           vectorBookingDetails[b].setDay(d);
		   vectorBookingDetails[b].setMonth(m);
		   vectorBookingDetails[b].setYear(y);
           break;
           valid=1;		   
          }
        b++;
       }
return valid;	
}

