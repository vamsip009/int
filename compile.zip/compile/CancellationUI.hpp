#ifndef _DEFCANCELLATIONVIEW
#define _DEFCANCELLATIONVIEW
#include "CancellationBean.hpp"

#include <iostream>
#include <string>
#include <vector>
using namespace std;

class CancellationUI {

public:
    int customerId;
    int day;
    int month;
    int year;
    int d,m,y;
    CancellationBean objectCancellationB;

    CancellationBean cancellationDetails();
        int cancellationday(CancellationBean);
              
       
        void displayStatus();
};
#endif
