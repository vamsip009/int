#include "BookingUI.hpp"

BookingBean BookingUI::bookingDetails()
{BookingBean objectBookingBean;
    cout << "\t\t\t\t\t Enter customerId:";
    cin >> customerId;
    cout << "\t\t\t\t\t Select your Tour Location from below list" << endl;
    cout << "\t\t\t\t\t 1.Brussels \n\t\t\t\t\t 2.Paris \n\t\t\t\t\t 3.Amsterdam \n\t\t\t\t\t 4.Lisbon \n\t\t\t\t\t 5.Alexandria \n\t\t\t\t\t 6.Capetown  \n\t\t\t\t\t 7.Mauritius \n\t\t\t\t\t 8.Kenya \n\t\t\t\t\t 9.Morocco \n\t\t\t\t\t 10.Greece \n\t\t\t\t\t 11.Istanbul \n\t\t\t\t\t 12.Scilly \n\t\t\t\t\t 13.Copenhagen";
    cin >> dest;
    cout << "\t\t\t\t\t Select 1 : Single, Select 2 : Couple" << endl;
    cin >> couple;
    cout << "\t\t\t\t\t Enter Number Of Extra Travellers other than Couple" << endl;
    cin >> notravelers;
    cout << "\t\t\t\t\t If Extra Traveller is Child enter 1 or else 0;" << endl;
    cin >> child;
    cout << "\t\t\t\t\t Select Your Specific Provisions" << endl;
    cout << "\t\t\t\t\t 1.HoneyMoon Couple \n\t\t\t\t\t 2.Senior citizens (above the age of 65) \n ";
    cin >> sp;
    cout << "\t\t\t\t\t Enter Bank Name:";
    cin >> bankName;
    cout << "\t\t\t\t\t Enter Transaction Mode NEFT OR RTGS:";
    cin >> transactionMode;
    cout << "\t\t\t\t\t Enter Account Number:";
    cin >> accountNumber;
    cout << "\t\t\t\t\t Enter travelling day:";
    cin >> day;
    cout << "\t\t\t\t\t Enter travelling month:";
    cin >> month;
    cout << "\t\t\t\t\t Enter travelling year:";
    cin >> year;
    cout << "\t\t\t\t\t Select your Booking location among the following:"<<endl;
    cout << "\t\t\t\t\t 1.Birmingham \n\t\t\t\t\t 2.Cambridge \n\t\t\t\t\t 3.Edinburgh \n\t\t\t\t\t 4.Glasglow \n\t\t\t\t\t 5.Nottingham\n";
    cout << "\t\t\t\t\t Enter booking location:";
    cin >> location;
    objectBookingBean.setCusomertId(customerId);
    cout<<"valid:::::::";
    objectBookingBean.setDest(dest);
    objectBookingBean.setCouple(couple);
    objectBookingBean.setChild(child);
    objectBookingBean.setSp(sp);
    objectBookingBean.setNotravelers(notravelers);
    objectBookingBean.setBankName(bankName);
    objectBookingBean.setTransactionMode(transactionMode);
    objectBookingBean.setAccountNumber(accountNumber);
    objectBookingBean.setDay(day);
    objectBookingBean.setMonth(month);
    objectBookingBean.setYear(year);
    objectBookingBean.setLocation(location);

    return objectBookingBean;
}

void BookingUI::bookingStatus()
{
    cout << "\n Your customer id is invalid";
}
void BookingUI::displayBill(BookingBean obbean)
{
    cout << "\t\t\t\t\t Your CustomerID:" << obbean.getCusomertId()<<endl;
    cout << "\t\t\t\t\t Your Total Bill is :" << obbean.getBill()<<endl;
    cout << "\t\t\t\t\t Your Booking is done successfully...\n";
    cout << "\t\t\t\t\t Thank You For Chossing Us !!! Visit Again";
}
