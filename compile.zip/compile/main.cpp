#include "CustomerController.hpp"
#include "BookingController.hpp"
#include "CancellationController.hpp"
#include "PostponeController.hpp"

#include <iostream>
#include <string>
#include <vector>
using namespace std;

int main()
{
	int choice;
	char ch;
        CustomerController customerControllerobject;
        BookingController bookingControllerObject;
        PostponeController postponeControllerObject;
        CancellationController cancellationControllerObject;
do{	
	cout<<"                          $$$$$$$$ Make your choice among the following :\n 1::CustomerDetails \n 2::BookingDetails \n 3:: Postponement Details\n 4:: Cancellation details $$$$$$$$                      "<<endl;
	cin>>choice;

	switch (choice)
	{
		case 1:	customerControllerobject.initiateCustomer();
				break;
		case 2: bookingControllerObject.initiateBooking();
				break;
		case 3: postponeControllerObject.initiatePostpone();
				break;		
		case 4: cancellationControllerObject.initiateCancellation();
				break;
		default: cout<< "Sorry!! Wrong Choice"<<endl;
	}
	cout<<"Do you want to continue y or n"<<endl;
	cin>>ch;
	}
	while(ch=='y');
	return 0;
}
