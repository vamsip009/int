#ifndef _DEFBOOKINGCONTROLLER

#define _DEFBOOKINGCONTROLLER

#include "BookingUI.hpp"

#include "Booking.hpp"

#include "BookingBean.hpp"

#include "BookingController.hpp"
#include "CustomerController.hpp"

#include <iostream>

#include <algorithm>

#include <string>

#include <vector>

using namespace std;

class BookingController

    {
    BookingUI objectBookingUI;
    CustomerController objectCustomerController;
    BookingBean objectBookingBean;
    BookingBean objectsetBookingBean;
    Booking objectBooking;

public:
    void initiateBooking();
	int verifyCID(int);
	int getDay(int);
	int getMonth(int);
	int getYear(int);
	int getNumtrv(int);
	int updateDate(int,int,int,int);
	
};

#endif

