#ifndef _DEFBOOKINGMODEL

#define _DEFBOOKINGMODEL

#include "BookingBean.hpp"

#include <iostream>

#include <vector>

#include <string>

#include <ctime>

#include <cstdio>

using namespace std;

class Booking

    {
    double bill;
    int notvlrs;
public:
    vector<BookingBean> vectorBookingDetails;
    BookingBean calculateBill(BookingBean);
	
	int verifyCid(int);
	int getDay(int);
	int getMonth(int);
	int getYear(int);
	int getNumtrv(int);
	int updateDate(int,int,int,int);
};

#endif
