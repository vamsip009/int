#include "CancellationUI.hpp"
CancellationBean CancellationUI::cancellationDetails()
{
    cout << "Enter Customer Id:";
    cin >> customerId;
    cout << "Enter day";
    cin >> day;
    cout << "Enter month";
    cin >> month;
    cout << "Enter year";
    cin >> year;
    objectCancellationB.setCustomerId(customerId);
    objectCancellationB.setDay(day);
    objectCancellationB.setMonth(month);
    objectCancellationB.setYear(year);
    return objectCancellationB;
}
int  CancellationUI::cancellationday(CancellationBean objectCancellationB)
{
        cout<<"The amount to be paid for Cancellation:"<<objectCancellationB.getAmountPaid();

        return d;
}


void CancellationUI::displayStatus()
{

        cout<<"Your Customer id is invalid"<<endl;
}
