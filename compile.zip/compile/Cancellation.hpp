#ifndef _DEFCANCELLATIONMODEL
#define _DEFCANCELLATIONMODEL
#include "CancellationBean.hpp"
#include "CancellationUI.hpp"
#include <iostream>
#include <vector>
#include <string>
#include <ctime>

using namespace std;
 struct Date {
        int d, m, y;
    };

class Cancellation {
public:


    int diff;
    int amountPaid;
    int cday, cmonth, cyear;
    int cdate;
    int difference;
    CancellationBean objectCancellationBean;

    CancellationBean updateCancellationDetails(CancellationBean, int, int, int,int);
};
#endif
